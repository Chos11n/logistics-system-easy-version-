import { Problem, User, Concept } from '../types';

// Mock user data
export const mockUser: User = {
  id: 'user1',
  name: 'Student',
  progress: {
    completedProblems: ['prob1', 'prob2'],
    masteredConcepts: ['concept1'],
    scoreHistory: [
      { date: '2025-01-01', score: 85, conceptId: 'concept1' },
      { date: '2025-01-05', score: 90, conceptId: 'concept1' },
      { date: '2025-01-10', score: 95, conceptId: 'concept2' },
    ],
  },
};

// Mock problems
export const mockProblems: Problem[] = [
  {
    id: 'prob1',
    title: 'Quadratic Equation',
    description: 'Solve the equation: x² - 5x + 6 = 0',
    type: 'algebra',
    difficulty: 'easy',
    visualizationType: 'geogebra',
    concepts: ['concept1', 'concept2'],
  },
  {
    id: 'prob2',
    title: 'Triangle Area',
    description: 'Calculate the area of a triangle with sides 3, 4, and 5',
    type: 'geometry',
    difficulty: 'medium',
    visualizationType: 'geogebra',
    concepts: ['concept3'],
  },
  {
    id: 'prob3',
    title: 'Function Derivative',
    description: 'Find the derivative of f(x) = x³ - 2x² + 4x - 1',
    type: 'calculus',
    difficulty: 'hard',
    visualizationType: 'geogebra',
    concepts: ['concept4'],
  },
  {
    id: 'prob4',
    title: '3D Geometry',
    description: 'Calculate the volume of a cone with radius 3 and height 4',
    type: 'geometry',
    difficulty: 'medium',
    visualizationType: 'threejs',
    concepts: ['concept5'],
  },
];

// Mock concepts
export const mockConcepts: Concept[] = [
  {
    id: 'concept1',
    name: 'Quadratic Equations',
    description: 'Equations of the form ax² + bx + c = 0',
    relatedConcepts: ['concept2'],
  },
  {
    id: 'concept2',
    name: 'Factoring',
    description: 'Breaking down expressions into products',
    relatedConcepts: ['concept1'],
  },
  {
    id: 'concept3',
    name: 'Triangle Properties',
    description: 'Properties and formulas related to triangles',
    relatedConcepts: ['concept5'],
  },
  {
    id: 'concept4',
    name: 'Derivatives',
    description: 'Rate of change of a function',
    relatedConcepts: [],
  },
  {
    id: 'concept5',
    name: '3D Shapes',
    description: 'Properties of three-dimensional geometric shapes',
    relatedConcepts: ['concept3'],
  },
];

// Recommended problems based on user progress
export const getRecommendedProblems = (userId: string): Problem[] => {
  // In a real app, this would use an algorithm based on the user's progress
  return mockProblems.filter(problem => !mockUser.progress.completedProblems.includes(problem.id)).slice(0, 3);
};