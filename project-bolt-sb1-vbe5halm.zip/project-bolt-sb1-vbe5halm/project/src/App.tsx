import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/layout/Layout';
import HomePage from './pages/HomePage';
import ProblemsPage from './pages/ProblemsPage';
import ProgressPage from './pages/ProgressPage';
import ProfilePage from './pages/ProfilePage';
import { useAppStore } from './store/appStore';
import { mockUser } from './data/mockData';

function App() {
  const { setCurrentUser } = useAppStore();
  
  // Initialize with mock user data
  React.useEffect(() => {
    setCurrentUser(mockUser);
  }, [setCurrentUser]);
  
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="problems" element={<ProblemsPage />} />
        <Route path="progress" element={<ProgressPage />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="*" element={<Navigate to="/\" replace />} />
      </Route>
    </Routes>
  );
}

export default App;