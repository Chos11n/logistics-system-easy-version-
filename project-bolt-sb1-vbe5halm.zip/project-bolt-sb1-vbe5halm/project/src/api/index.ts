import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  timeout: 10000,
});

export interface ProblemRequest {
  text?: string;
  image?: File;
}

export interface ActionRequest {
  problemId: string;
  action: string;
  parameters: Record<string, any>;
}

export interface VerifyResponse {
  status: 'correct' | 'incorrect' | 'partial' | 'pending';
  message?: string;
  suggestions?: string[];
}

export interface DashboardData {
  recentScores: Array<{
    date: string;
    score: number;
    conceptId: string;
  }>;
  problemStats: {
    total: number;
    completed: number;
    accuracy: number;
  };
  conceptMastery: Array<{
    id: string;
    name: string;
    progress: number;
  }>;
}

export interface RecommendedProblem {
  id: string;
  title: string;
  description: string;
  difficulty: string;
  type: string;
}

export const submitProblem = async (data: ProblemRequest) => {
  const formData = new FormData();
  if (data.text) formData.append('text', data.text);
  if (data.image) formData.append('image', data.image);
  
  const response = await api.post('/problem', formData);
  return response.data;
};

export const submitAction = async (data: ActionRequest) => {
  const response = await api.post('/actions', data);
  return response.data;
};

export const verifyAnswer = async (problemId: string) => {
  const response = await api.get<VerifyResponse>(`/verify/${problemId}`);
  return response.data;
};

export const getDashboardData = async () => {
  const response = await api.get<DashboardData>('/dashboard');
  return response.data;
};

export const getRecommendedProblems = async () => {
  const response = await api.get<RecommendedProblem[]>('/recommend');
  return response.data;
};