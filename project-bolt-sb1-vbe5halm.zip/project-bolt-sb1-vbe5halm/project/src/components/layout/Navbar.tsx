import React from 'react';
import { NavLink } from 'react-router-dom';
import { Menu, X, BookOpen, LineChart, User, Home } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAppStore } from '../../store/appStore';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const { toggleJoyride } = useAppStore();

  const navItems = [
    { name: 'Home', path: '/', icon: <Home className="w-5 h-5" />, className: 'nav-home' },
    { name: 'Problems', path: '/problems', icon: <BookOpen className="w-5 h-5" /> },
    { name: 'Progress', path: '/progress', icon: <LineChart className="w-5 h-5" /> },
    { name: 'Profile', path: '/profile', icon: <User className="w-5 h-5" /> },
  ];

  return (
    <header className="bg-white shadow-md">
      <nav className="container mx-auto px-4 py-3 flex justify-between items-center">
        {/* Logo and Title */}
        <div className="flex items-center space-x-2">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center"
          >
            <NavLink to="/" className="text-primary-600 font-bold text-xl flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-8 h-8 mr-2"
              >
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="16" />
                <line x1="8" y1="12" x2="16" y2="12" />
              </svg>
              <span className="hidden sm:inline">MathVision</span>
            </NavLink>
          </motion.div>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-6">
          {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) =>
                `${item.className || ''} flex items-center text-base font-medium ${
                  isActive
                    ? 'text-primary-600 border-b-2 border-primary-600'
                    : 'text-neutral-600 hover:text-primary-500'
                }`
              }
            >
              <span className="mr-1">{item.icon}</span>
              <span>{item.name}</span>
            </NavLink>
          ))}
        </div>

        {/* Help Button */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={toggleJoyride}
          className="hidden md:flex items-center px-4 py-2 rounded-md bg-accent-500 text-white font-medium hover:bg-accent-600 transition-colors"
        >
          <span>Help</span>
        </motion.button>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-neutral-700 focus:outline-none"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="md:hidden bg-white px-4 py-2 shadow-lg"
        >
          <div className="flex flex-col space-y-3">
            {navItems.map((item) => (
              <NavLink
                key={item.name}
                to={item.path}
                className={({ isActive }) =>
                  `${item.className || ''} flex items-center p-2 rounded-md ${
                    isActive
                      ? 'bg-primary-50 text-primary-600'
                      : 'text-neutral-600 hover:bg-neutral-50'
                  }`
                }
                onClick={() => setIsMenuOpen(false)}
              >
                <span className="mr-3">{item.icon}</span>
                <span>{item.name}</span>
              </NavLink>
            ))}
            <button
              onClick={() => {
                toggleJoyride();
                setIsMenuOpen(false);
              }}
              className="flex items-center p-2 text-accent-500 hover:bg-neutral-50 rounded-md"
            >
              <span>Help</span>
            </button>
          </div>
        </motion.div>
      )}
    </header>
  );
};

export default Navbar;