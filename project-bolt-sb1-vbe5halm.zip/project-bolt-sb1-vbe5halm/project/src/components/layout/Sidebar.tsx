import React from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, BookOpen, Lightbulb, Wrench } from 'lucide-react';
import { useAppStore } from '../../store/appStore';
import { mockProblems, mockConcepts } from '../../data/mockData';

const Sidebar: React.FC = () => {
  const { isSidebarOpen, toggleSidebar } = useAppStore();
  const [activeTab, setActiveTab] = React.useState<'problems' | 'concepts' | 'tools'>('problems');

  const sidebarVariants = {
    open: { width: '280px', transition: { duration: 0.3 } },
    closed: { width: '48px', transition: { duration: 0.3 } },
  };

  const tabContentVariants = {
    hidden: { opacity: 0, x: -10 },
    visible: { opacity: 1, x: 0, transition: { delay: 0.1, duration: 0.3 } },
  };

  const renderTabContent = () => {
    if (!isSidebarOpen) return null;

    switch (activeTab) {
      case 'problems':
        return (
          <motion.div
            variants={tabContentVariants}
            initial="hidden"
            animate="visible"
            className="space-y-2"
          >
            <h3 className="font-medium text-neutral-700 mb-3">Problem Library</h3>
            {mockProblems.map((problem) => (
              <button
                key={problem.id}
                className="w-full text-left p-2 text-sm rounded-md hover:bg-primary-50 focus:outline-none focus:ring-2 focus:ring-primary-200 text-neutral-700 transition-colors"
              >
                <div className="font-medium">{problem.title}</div>
                <div className="flex space-x-2 mt-1">
                  <span className="text-xs px-2 py-0.5 bg-primary-100 text-primary-700 rounded-full">
                    {problem.type}
                  </span>
                  <span className="text-xs px-2 py-0.5 bg-neutral-100 text-neutral-700 rounded-full">
                    {problem.difficulty}
                  </span>
                </div>
              </button>
            ))}
          </motion.div>
        );
      case 'concepts':
        return (
          <motion.div
            variants={tabContentVariants}
            initial="hidden"
            animate="visible"
            className="space-y-2"
          >
            <h3 className="font-medium text-neutral-700 mb-3">Knowledge Map</h3>
            {mockConcepts.map((concept) => (
              <button
                key={concept.id}
                className="w-full text-left p-2 text-sm rounded-md hover:bg-primary-50 focus:outline-none focus:ring-2 focus:ring-primary-200 text-neutral-700 transition-colors"
              >
                <div className="font-medium">{concept.name}</div>
                <div className="text-xs text-neutral-500 mt-0.5">{concept.description}</div>
              </button>
            ))}
          </motion.div>
        );
      case 'tools':
        return (
          <motion.div
            variants={tabContentVariants}
            initial="hidden"
            animate="visible"
            className="space-y-2"
          >
            <h3 className="font-medium text-neutral-700 mb-3">Interactive Tools</h3>
            <button className="w-full text-left p-2 text-sm rounded-md hover:bg-primary-50 focus:outline-none focus:ring-2 focus:ring-primary-200 text-neutral-700 transition-colors">
              <div className="font-medium">GeoGebra Calculator</div>
              <div className="text-xs text-neutral-500 mt-0.5">2D visualizations</div>
            </button>
            <button className="w-full text-left p-2 text-sm rounded-md hover:bg-primary-50 focus:outline-none focus:ring-2 focus:ring-primary-200 text-neutral-700 transition-colors">
              <div className="font-medium">3D Geometry</div>
              <div className="text-xs text-neutral-500 mt-0.5">Three.js visualizations</div>
            </button>
            <button className="w-full text-left p-2 text-sm rounded-md hover:bg-primary-50 focus:outline-none focus:ring-2 focus:ring-primary-200 text-neutral-700 transition-colors">
              <div className="font-medium">Formula Sheet</div>
              <div className="text-xs text-neutral-500 mt-0.5">Common equations reference</div>
            </button>
          </motion.div>
        );
      default:
        return null;
    }
  };

  return (
    <motion.aside
      className="h-[calc(100vh-64px)] bg-white border-r border-neutral-200 fixed left-0 top-16 z-10 overflow-hidden flex flex-col"
      variants={sidebarVariants}
      animate={isSidebarOpen ? 'open' : 'closed'}
      initial={isSidebarOpen ? 'open' : 'closed'}
    >
      <div className="flex items-center justify-end p-2">
        <button
          onClick={toggleSidebar}
          className="p-1 rounded-full hover:bg-neutral-100 focus:outline-none"
          aria-label={isSidebarOpen ? 'Close sidebar' : 'Open sidebar'}
        >
          {isSidebarOpen ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
        </button>
      </div>

      {isSidebarOpen ? (
        <div className="flex-1 p-3 overflow-y-auto">
          <div className="flex space-x-2 mb-4">
            <button
              onClick={() => setActiveTab('problems')}
              className={`flex items-center justify-center p-2 rounded-md flex-1 ${
                activeTab === 'problems'
                  ? 'bg-primary-100 text-primary-700'
                  : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <BookOpen size={18} />
              <span className="ml-1 text-sm">Problems</span>
            </button>
            <button
              onClick={() => setActiveTab('concepts')}
              className={`flex items-center justify-center p-2 rounded-md flex-1 ${
                activeTab === 'concepts'
                  ? 'bg-primary-100 text-primary-700'
                  : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <Lightbulb size={18} />
              <span className="ml-1 text-sm">Concepts</span>
            </button>
            <button
              onClick={() => setActiveTab('tools')}
              className={`flex items-center justify-center p-2 rounded-md flex-1 ${
                activeTab === 'tools'
                  ? 'bg-primary-100 text-primary-700'
                  : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <Wrench size={18} />
              <span className="ml-1 text-sm">Tools</span>
            </button>
          </div>
          {renderTabContent()}
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center py-4 space-y-6">
          <button
            onClick={() => {
              toggleSidebar();
              setActiveTab('problems');
            }}
            className={`p-2 rounded-md ${
              activeTab === 'problems' ? 'bg-primary-100 text-primary-700' : 'text-neutral-600'
            }`}
            aria-label="Problems"
          >
            <BookOpen size={20} />
          </button>
          <button
            onClick={() => {
              toggleSidebar();
              setActiveTab('concepts');
            }}
            className={`p-2 rounded-md ${
              activeTab === 'concepts' ? 'bg-primary-100 text-primary-700' : 'text-neutral-600'
            }`}
            aria-label="Concepts"
          >
            <Lightbulb size={20} />
          </button>
          <button
            onClick={() => {
              toggleSidebar();
              setActiveTab('tools');
            }}
            className={`p-2 rounded-md ${
              activeTab === 'tools' ? 'bg-primary-100 text-primary-700' : 'text-neutral-600'
            }`}
            aria-label="Tools"
          >
            <Wrench size={20} />
          </button>
        </div>
      )}
    </motion.aside>
  );
};

export default Sidebar;