import React from 'react';
import { Outlet } from 'react-router-dom';
import Joyride, { CallBackProps, STATUS } from 'react-joyride';
import { useAppStore } from '../../store/appStore';
import Navbar from './Navbar';
import Sidebar from './Sidebar';

const Layout: React.FC = () => {
  const { isSidebarOpen, isJoyrideActive, toggleJoyride, steps } = useAppStore();

  const handleJoyrideCallback = (data: CallBackProps) => {
    const { status } = data;
    if ([STATUS.FINISHED, STATUS.SKIPPED].includes(status)) {
      toggleJoyride();
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      <Joyride
        steps={steps}
        run={isJoyrideActive}
        continuous
        showProgress
        showSkipButton
        styles={{
          options: {
            primaryColor: '#3B82F6',
            zIndex: 1000,
          },
        }}
        callback={handleJoyrideCallback}
      />
      
      <Navbar />
      
      <div className="flex flex-1 relative">
        <Sidebar />
        
        <main
          className={`flex-1 transition-all duration-300 ${
            isSidebarOpen ? 'md:ml-[280px]' : 'md:ml-[48px]'
          }`}
        >
          <div className="container mx-auto px-4 py-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;