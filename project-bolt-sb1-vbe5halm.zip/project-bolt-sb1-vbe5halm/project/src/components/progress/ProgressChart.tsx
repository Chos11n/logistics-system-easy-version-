import React, { useEffect, useState } from 'react';
import Plot from 'react-plotly.js';
import { getDashboardData } from '../../api';
import { ScoreEntry } from '../../types';

interface ProgressChartProps {
  title?: string;
  height?: number;
}

const ProgressChart: React.FC<ProgressChartProps> = ({
  title = 'Learning Progress',
  height = 300,
}) => {
  const [data, setData] = useState<ScoreEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const dashboardData = await getDashboardData();
        setData(dashboardData.recentScores);
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[300px] bg-white rounded-lg">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500"></div>
      </div>
    );
  }
  
  // Process data for plotting
  const dates = data.map((entry) => entry.date);
  const scores = data.map((entry) => entry.score);
  
  // Group data by concept
  const conceptGroups = data.reduce((acc, entry) => {
    if (!acc[entry.conceptId]) {
      acc[entry.conceptId] = {
        dates: [],
        scores: [],
      };
    }
    acc[entry.conceptId].dates.push(entry.date);
    acc[entry.conceptId].scores.push(entry.score);
    return acc;
  }, {} as Record<string, { dates: string[]; scores: number[] }>);
  
  // Chart layout
  const layout = {
    title: title,
    autosize: true,
    height: height,
    margin: { l: 50, r: 30, b: 50, t: 80, pad: 4 },
    xaxis: {
      title: 'Date',
      showgrid: true,
      gridcolor: '#E5E7EB',
    },
    yaxis: {
      title: 'Score',
      range: [0, 100],
      showgrid: true,
      gridcolor: '#E5E7EB',
    },
    plot_bgcolor: 'rgba(0,0,0,0)',
    paper_bgcolor: 'rgba(0,0,0,0)',
    font: {
      family: 'ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    },
    legend: {
      orientation: 'h',
      y: -0.2,
    },
  };
  
  return (
    <div className="progress-section bg-white rounded-lg shadow-md p-4">
      <Plot
        data={[
          {
            x: dates,
            y: scores,
            type: 'scatter',
            mode: 'lines+markers',
            marker: { color: '#3B82F6', size: 8 },
            line: { color: '#3B82F6', width: 2 },
            name: 'Overall Progress',
          },
          ...Object.entries(conceptGroups).map(([conceptId, { dates, scores }], index) => ({
            x: dates,
            y: scores,
            type: 'scatter',
            mode: 'markers',
            marker: { 
              color: [
                '#14B8A6', // teal
                '#8B5CF6', // purple
                '#F59E0B', // amber
                '#EC4899', // pink
              ][index % 4], 
              size: 8,
              symbol: 'circle-open',
            },
            name: `Concept ${conceptId}`,
          })),
        ]}
        layout={layout}
        config={{ responsive: true }}
        style={{ width: '100%' }}
      />
    </div>
  );
};

export default ProgressChart;