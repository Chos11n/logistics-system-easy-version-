import React, { useEffect, useRef } from 'react';
import { submitAction } from '../../api';

interface GeoGebraWrapperProps {
  id: string;
  problemId: string;
  commands?: string[];
  width?: string;
  height?: string;
  onLoad?: () => void;
}

declare global {
  interface Window {
    GGBApplet: any;
  }
}

const GeoGebraWrapper: React.FC<GeoGebraWrapperProps> = ({
  id,
  problemId,
  commands = [],
  width = '100%',
  height = '400px',
  onLoad,
}) => {
  const appletRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const loadedRef = useRef(false);

  useEffect(() => {
    const loadGeoGebra = () => {
      const script = document.createElement('script');
      script.src = 'https://www.geogebra.org/apps/deployggb.js';
      script.async = true;
      script.onload = initGeoGebra;
      document.body.appendChild(script);
    };

    const initGeoGebra = () => {
      if (!window.GGBApplet) return;

      const params = {
        id,
        width,
        height,
        showMenuBar: false,
        showAlgebraInput: true,
        showToolBar: true,
        showToolBarHelp: false,
        showResetIcon: true,
        enableLabelDrags: false,
        enableShiftDragZoom: true,
        enableRightClick: false,
        errorDialogsActive: true,
        useBrowserForJS: false,
        allowStyleBar: false,
        preventFocus: false,
        showZoomButtons: true,
        appletOnLoad: handleAppletLoad,
      };

      appletRef.current = new window.GGBApplet(params, true);
      
      if (containerRef.current) {
        appletRef.current.inject(containerRef.current);
      }
    };

    const handleAppletLoad = () => {
      loadedRef.current = true;
      
      if (commands.length > 0 && appletRef.current) {
        commands.forEach((cmd) => {
          appletRef.current.evalCommand(cmd);
        });
      }

      // Register event listeners
      if (appletRef.current) {
        appletRef.current.registerUpdateListener(handleUpdate);
        appletRef.current.registerAddListener(handleAdd);
        appletRef.current.registerRemoveListener(handleRemove);
        appletRef.current.registerClickListener(handleClick);
      }
      
      if (onLoad) {
        onLoad();
      }
    };

    const handleUpdate = (objName: string) => {
      const value = appletRef.current?.getValue(objName);
      submitAction({
        problemId,
        action: 'update',
        parameters: { object: objName, value },
      });
    };

    const handleAdd = (objName: string) => {
      submitAction({
        problemId,
        action: 'add',
        parameters: { object: objName },
      });
    };

    const handleRemove = (objName: string) => {
      submitAction({
        problemId,
        action: 'remove',
        parameters: { object: objName },
      });
    };

    const handleClick = (objName: string) => {
      submitAction({
        problemId,
        action: 'click',
        parameters: { object: objName },
      });
    };

    loadGeoGebra();

    return () => {
      if (appletRef.current) {
        appletRef.current.unregisterUpdateListener(handleUpdate);
        appletRef.current.unregisterAddListener(handleAdd);
        appletRef.current.unregisterRemoveListener(handleRemove);
        appletRef.current.unregisterClickListener(handleClick);
      }
    };
  }, [id, width, height, onLoad, problemId, commands]);

  return <div ref={containerRef} id={`ggb-container-${id}`} className="visualization-area w-full" />;
};

export default GeoGebraWrapper;