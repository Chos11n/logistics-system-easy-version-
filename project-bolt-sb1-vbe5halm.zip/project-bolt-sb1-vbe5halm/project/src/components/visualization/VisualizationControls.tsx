import React from 'react';
import { motion } from 'framer-motion';
import { Box, PenSquare, Move, ZoomIn, ZoomOut, RotateCcw, Save } from 'lucide-react';
import { useAppStore } from '../../store/appStore';

interface VisualizationControlsProps {
  onReset?: () => void;
  onSave?: () => void;
}

const VisualizationControls: React.FC<VisualizationControlsProps> = ({ onReset, onSave }) => {
  const { visualizationMode, setVisualizationMode } = useAppStore();
  
  const toolButtons = [
    { icon: <PenSquare size={18} />, label: 'Draw', tooltip: 'Draw shapes or points' },
    { icon: <Move size={18} />, label: 'Move', tooltip: 'Move objects' },
    { icon: <ZoomIn size={18} />, label: 'Zoom In', tooltip: 'Zoom in' },
    { icon: <ZoomOut size={18} />, label: 'Zoom Out', tooltip: 'Zoom out' },
  ];
  
  return (
    <div className="tools-panel bg-white p-3 rounded-lg shadow-md mb-4">
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-base font-medium text-neutral-700">Visualization Controls</h3>
        
        <div className="flex items-center space-x-2">
          <button
            className={`p-1.5 rounded-md text-xs font-medium ${
              visualizationMode === '2d'
                ? 'bg-primary-100 text-primary-700'
                : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
            }`}
            onClick={() => setVisualizationMode('2d')}
          >
            2D
          </button>
          <button
            className={`p-1.5 rounded-md text-xs font-medium ${
              visualizationMode === '3d'
                ? 'bg-primary-100 text-primary-700'
                : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
            }`}
            onClick={() => setVisualizationMode('3d')}
          >
            <Box size={14} className="inline mr-1" />
            3D
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-4 gap-2 mb-3">
        {toolButtons.map((tool, index) => (
          <motion.button
            key={index}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex flex-col items-center justify-center p-2 bg-neutral-50 hover:bg-neutral-100 rounded-md text-neutral-700"
            title={tool.tooltip}
          >
            {tool.icon}
            <span className="text-xs mt-1">{tool.label}</span>
          </motion.button>
        ))}
      </div>
      
      <div className="flex justify-between">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center px-3 py-1.5 text-sm bg-neutral-100 hover:bg-neutral-200 rounded-md text-neutral-700"
          onClick={onReset}
        >
          <RotateCcw size={14} className="mr-1" />
          Reset
        </motion.button>
        
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center px-3 py-1.5 text-sm bg-primary-500 hover:bg-primary-600 rounded-md text-white"
          onClick={onSave}
        >
          <Save size={14} className="mr-1" />
          Save
        </motion.button>
      </div>
    </div>
  );
};

export default VisualizationControls;