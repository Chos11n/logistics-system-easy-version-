import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, XCircle, AlertCircle, ArrowRight } from 'lucide-react';

interface FeedbackPanelProps {
  status: 'correct' | 'incorrect' | 'partial' | 'pending';
  message?: string;
  suggestions?: string[];
  onTryAgain?: () => void;
  onNextProblem?: () => void;
}

const FeedbackPanel: React.FC<FeedbackPanelProps> = ({
  status,
  message = '',
  suggestions = [],
  onTryAgain,
  onNextProblem,
}) => {
  const statusConfig = {
    correct: {
      icon: <CheckCircle className="w-6 h-6 text-success-500" />,
      title: 'Correct!',
      bg: 'bg-success-50',
      border: 'border-success-200',
      text: 'text-success-700',
    },
    incorrect: {
      icon: <XCircle className="w-6 h-6 text-error-500" />,
      title: 'Not quite right',
      bg: 'bg-error-50',
      border: 'border-error-200',
      text: 'text-error-700',
    },
    partial: {
      icon: <AlertCircle className="w-6 h-6 text-warning-500" />,
      title: 'Partially correct',
      bg: 'bg-warning-50',
      border: 'border-warning-200',
      text: 'text-warning-700',
    },
    pending: {
      icon: <div className="w-6 h-6 border-2 border-neutral-300 border-t-primary-500 rounded-full animate-spin" />,
      title: 'Checking your answer...',
      bg: 'bg-neutral-50',
      border: 'border-neutral-200',
      text: 'text-neutral-700',
    },
  };
  
  const config = statusConfig[status];
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`p-4 rounded-lg ${config.bg} border ${config.border} mb-6`}
    >
      <div className="flex items-start">
        <div className="mr-3 mt-0.5">{config.icon}</div>
        
        <div className="flex-1">
          <h3 className={`font-semibold ${config.text}`}>{config.title}</h3>
          
          {message && (
            <p className="text-neutral-700 mt-2">{message}</p>
          )}
          
          {suggestions.length > 0 && (
            <div className="mt-3">
              <h4 className="text-sm font-medium text-neutral-700 mb-2">Suggestions:</h4>
              <ul className="text-sm text-neutral-600 space-y-1">
                {suggestions.map((suggestion, index) => (
                  <li key={index} className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>{suggestion}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          {status !== 'pending' && (
            <div className="flex mt-4 space-x-3">
              {status !== 'correct' && onTryAgain && (
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="px-3 py-1.5 text-sm border border-neutral-300 rounded-md hover:bg-neutral-100"
                  onClick={onTryAgain}
                >
                  Try Again
                </motion.button>
              )}
              
              {onNextProblem && (
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`px-3 py-1.5 text-sm rounded-md flex items-center ${
                    status === 'correct'
                      ? 'bg-primary-500 text-white hover:bg-primary-600'
                      : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                  }`}
                  onClick={onNextProblem}
                >
                  <span>Next Problem</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </motion.button>
              )}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default FeedbackPanel;