import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { motion } from 'framer-motion';
import { Upload, X, Image as ImageIcon } from 'lucide-react';

interface ImageInputProps {
  onImageUpload: (file: File) => void;
}

const ImageInput: React.FC<ImageInputProps> = ({ onImageUpload }) => {
  const [preview, setPreview] = useState<string | null>(null);

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      if (acceptedFiles.length > 0) {
        const file = acceptedFiles[0];
        onImageUpload(file);
        
        // Create a preview
        const reader = new FileReader();
        reader.onload = () => {
          setPreview(reader.result as string);
        };
        reader.readAsDataURL(file);
      }
    },
    [onImageUpload]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif'],
    },
    maxFiles: 1,
  });

  const clearPreview = () => {
    setPreview(null);
  };

  return (
    <div className="problem-input bg-white rounded-lg shadow-md p-4 mb-6">
      <h2 className="text-lg font-semibold text-neutral-800 mb-3">Upload a problem image</h2>
      
      <div 
        {...getRootProps()} 
        className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
          isDragActive 
            ? 'border-primary-500 bg-primary-50' 
            : 'border-neutral-300 hover:border-primary-400 hover:bg-neutral-50'
        }`}
      >
        <input {...getInputProps()} />
        
        {!preview ? (
          <div className="space-y-3">
            <div className="flex justify-center">
              <Upload className="h-12 w-12 text-neutral-400" />
            </div>
            <p className="text-neutral-600">
              {isDragActive
                ? 'Drop the image here...'
                : 'Drag & drop an image, or click to select'}
            </p>
            <p className="text-xs text-neutral-500">
              Supports JPG, PNG, GIF (max. 5MB)
            </p>
          </div>
        ) : (
          <div className="relative">
            <img 
              src={preview} 
              alt="Problem preview" 
              className="max-h-64 mx-auto rounded" 
            />
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="absolute top-2 right-2 p-1 bg-neutral-800 bg-opacity-70 text-white rounded-full hover:bg-opacity-100"
              onClick={(e) => {
                e.stopPropagation();
                clearPreview();
              }}
            >
              <X size={16} />
            </motion.button>
          </div>
        )}
      </div>
      
      {!preview && (
        <div className="mt-4">
          <p className="text-sm text-neutral-600 mb-2">For best results:</p>
          <ul className="text-xs text-neutral-500 list-disc pl-5">
            <li>Ensure the image is clear and well-lit</li>
            <li>Make sure the math problem is legible</li>
            <li>Crop out unnecessary parts of the image</li>
          </ul>
        </div>
      )}
      
      {preview && (
        <motion.button
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 w-full py-2 bg-primary-500 text-white rounded-md hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-300 flex items-center justify-center"
        >
          <ImageIcon size={18} className="mr-2" />
          <span>Process Image</span>
        </motion.button>
      )}
    </div>
  );
};

export default ImageInput;