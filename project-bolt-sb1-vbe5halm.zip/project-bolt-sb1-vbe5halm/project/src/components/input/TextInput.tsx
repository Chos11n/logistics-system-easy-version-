import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send } from 'lucide-react';
import { submitProblem } from '../../api';
import 'katex/dist/katex.min.css';

const renderMath = (text: string) => {
  return text.replace(/\$(.*?)\$/g, '<span class="katex">$1</span>');
};

interface TextInputProps {
  onSubmit: (text: string) => void;
}

const TextInput: React.FC<TextInputProps> = ({ onSubmit }) => {
  const [inputText, setInputText] = useState('');
  const [previewText, setPreviewText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const text = e.target.value;
    setInputText(text);
    setPreviewText(renderMath(text));
  };

  const handleSubmit = async () => {
    if (inputText.trim() && !isSubmitting) {
      setIsSubmitting(true);
      try {
        await submitProblem({ text: inputText.trim() });
        onSubmit(inputText.trim());
        setInputText('');
        setPreviewText('');
      } catch (error) {
        console.error('Failed to submit problem:', error);
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleSubmit();
    }
  };

  return (
    <div className="problem-input bg-white rounded-lg shadow-md p-4 mb-6">
      <h2 className="text-lg font-semibold text-neutral-800 mb-3">Enter your math problem</h2>
      
      <div className="flex flex-col space-y-4">
        <div className="relative">
          <textarea
            className="w-full h-32 p-3 border border-neutral-300 rounded-md focus:ring-2 focus:ring-primary-300 focus:border-primary-500 focus:outline-none resize-none"
            placeholder="Type your math problem here... (e.g., 'Solve x² - 5x + 6 = 0' or 'Find the area of a triangle with sides 3, 4, and 5')"
            value={inputText}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            disabled={isSubmitting}
          />
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`absolute right-3 bottom-3 p-2 bg-primary-500 text-white rounded-full hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-300 ${
              isSubmitting ? 'opacity-50 cursor-not-allowed' : ''
            }`}
            onClick={handleSubmit}
            disabled={isSubmitting}
            aria-label="Submit"
          >
            <Send size={18} className={isSubmitting ? 'animate-pulse' : ''} />
          </motion.button>
        </div>
        
        {previewText && (
          <div className="preview-section border border-neutral-200 rounded-md p-3 bg-neutral-50">
            <h3 className="text-sm font-medium text-neutral-500 mb-2">Preview:</h3>
            <div
              className="text-neutral-800"
              dangerouslySetInnerHTML={{ __html: previewText }}
            />
          </div>
        )}
        
        <div className="text-xs text-neutral-500">
          Tips:
          <ul className="list-disc pl-5 mt-1">
            <li>Use $ symbols around mathematical expressions (e.g., $x^2 + 3x$)</li>
            <li>Press Ctrl+Enter to quickly submit</li>
            <li>For fractions, use {String.raw`\frac{numerator}{denominator}`}</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default TextInput;