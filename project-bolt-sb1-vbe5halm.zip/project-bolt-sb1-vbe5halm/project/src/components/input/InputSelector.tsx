import React from 'react';
import { motion } from 'framer-motion';
import { Type, Image, ArrowRight } from 'lucide-react';
import { InputMode } from '../../types';

interface InputSelectorProps {
  activeMode: InputMode;
  onModeChange: (mode: InputMode) => void;
}

const InputSelector: React.FC<InputSelectorProps> = ({ activeMode, onModeChange }) => {
  return (
    <div className="flex space-x-4 mb-4">
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className={`flex items-center px-4 py-3 rounded-md flex-1 ${
          activeMode === 'text'
            ? 'bg-primary-100 text-primary-700 border border-primary-200'
            : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
        }`}
        onClick={() => onModeChange('text')}
      >
        <Type className="w-5 h-5 mr-2" />
        <span className="font-medium">Text Input</span>
        {activeMode === 'text' && (
          <ArrowRight className="w-4 h-4 ml-auto text-primary-500" />
        )}
      </motion.button>
      
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className={`flex items-center px-4 py-3 rounded-md flex-1 ${
          activeMode === 'image'
            ? 'bg-primary-100 text-primary-700 border border-primary-200'
            : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
        }`}
        onClick={() => onModeChange('image')}
      >
        <Image className="w-5 h-5 mr-2" />
        <span className="font-medium">Image Upload</span>
        {activeMode === 'image' && (
          <ArrowRight className="w-4 h-4 ml-auto text-primary-500" />
        )}
      </motion.button>
    </div>
  );
};

export default InputSelector;