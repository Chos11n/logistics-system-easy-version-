import { create } from 'zustand';
import { StepProps } from 'react-joyride';

interface AppState {
  isFirstVisit: boolean;
  completeFirstVisit: () => void;
  joyrideSteps: StepProps[];
  joyrideRun: boolean;
  setJoyrideRun: (run: boolean) => void;
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const useStore = create<AppState>((set) => ({
  // First visit state
  isFirstVisit: true,
  completeFirstVisit: () => set({ isFirstVisit: false }),
  
  // Joyride state
  joyrideSteps: [
    {
      target: '.navbar',
      content: 'Welcome to Math Explorer! This is the navigation bar where you can access all features.',
      disableBeacon: true,
    },
    {
      target: '.problem-input',
      content: 'Here you can input math problems using text or by uploading images.',
    },
    {
      target: '.visualization-area',
      content: 'This is where you'll see the visual representation of math problems.',
    },
    {
      target: '.sidebar',
      content: 'Here you can find a library of problems and additional tools.',
    },
  ],
  joyrideRun: false,
  setJoyrideRun: (run) => set({ joyrideRun: run }),
  
  // Sidebar state
  isSidebarOpen: true,
  toggleSidebar: () => set((state) => ({ isSidebarOpen: !state.isSidebarOpen })),
  
  // Navigation state
  activeTab: 'home',
  setActiveTab: (tab) => set({ activeTab: tab }),
}));