import { create } from 'zustand';
import { AppState, JoyrideStep } from '../types';

// Define initial joyride steps
const initialSteps: JoyrideStep[] = [
  {
    target: '.nav-home',
    content: 'Welcome to the Interactive Mathematics Learning Platform! This is your homepage.',
    title: 'Welcome!',
    placement: 'bottom',
  },
  {
    target: '.problem-input',
    content: 'Enter your math problem here or upload an image.',
    title: 'Problem Input',
    placement: 'bottom',
  },
  {
    target: '.visualization-area',
    content: 'Interactive visualizations will appear here to help you understand the problem.',
    title: 'Visualization',
    placement: 'top',
  },
  {
    target: '.tools-panel',
    content: 'Use these tools to interact with the visualization.',
    title: 'Interactive Tools',
    placement: 'left',
  },
  {
    target: '.progress-section',
    content: 'Track your learning progress and achievements here.',
    title: 'Progress Tracking',
    placement: 'top',
  },
];

// Create the store
export const useAppStore = create<AppState>((set) => ({
  currentUser: null,
  currentProblem: null,
  inputMode: 'text',
  isJoyrideActive: false,
  isSidebarOpen: true,
  visualizationMode: '2d',
  steps: initialSteps,
  
  // Actions
  setCurrentUser: (user) => set({ currentUser: user }),
  setCurrentProblem: (problem) => set({ currentProblem: problem }),
  setInputMode: (mode) => set({ inputMode: mode }),
  toggleJoyride: () => set((state) => ({ isJoyrideActive: !state.isJoyrideActive })),
  toggleSidebar: () => set((state) => ({ isSidebarOpen: !state.isSidebarOpen })),
  setVisualizationMode: (mode) => set({ visualizationMode: mode }),
}));