export interface User {
  id: string;
  name: string;
  progress: Progress;
}

export interface Progress {
  completedProblems: string[];
  masteredConcepts: string[];
  scoreHistory: ScoreEntry[];
}

export interface ScoreEntry {
  date: string;
  score: number;
  conceptId: string;
}

export interface Problem {
  id: string;
  title: string;
  description: string;
  type: 'algebra' | 'geometry' | 'calculus' | 'other';
  difficulty: 'easy' | 'medium' | 'hard';
  visualizationType: 'geogebra' | 'threejs' | 'none';
  concepts: string[];
}

export interface Concept {
  id: string;
  name: string;
  description: string;
  relatedConcepts: string[];
}

export type InputMode = 'text' | 'image';

export interface AppState {
  currentUser: User | null;
  currentProblem: Problem | null;
  inputMode: InputMode;
  isJoyrideActive: boolean;
  isSidebarOpen: boolean;
  visualizationMode: '2d' | '3d';
  steps: JoyrideStep[];
  
  // Actions
  setCurrentUser: (user: User | null) => void;
  setCurrentProblem: (problem: Problem | null) => void;
  setInputMode: (mode: InputMode) => void;
  toggleJoyride: () => void;
  toggleSidebar: () => void;
  setVisualizationMode: (mode: '2d' | '3d') => void;
}

export interface JoyrideStep {
  target: string;
  content: string;
  title?: string;
  placement?: 'top' | 'bottom' | 'left' | 'right';
}