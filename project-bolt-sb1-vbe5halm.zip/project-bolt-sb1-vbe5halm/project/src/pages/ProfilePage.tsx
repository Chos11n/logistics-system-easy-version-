import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Mail, BookOpen, Award, Settings, Bell, ChevronRight } from 'lucide-react';
import { mockUser } from '../data/mockData';

const ProfilePage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'account' | 'preferences'>('account');
  
  return (
    <div className="max-w-5xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-neutral-800 mb-2">My Profile</h1>
        <p className="text-neutral-600">
          Manage your account settings and preferences
        </p>
      </motion.div>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-4 mb-4">
            <div className="flex flex-col items-center text-center">
              <div className="w-24 h-24 rounded-full bg-primary-100 flex items-center justify-center mb-4">
                <User className="w-12 h-12 text-primary-500" />
              </div>
              <h2 className="text-xl font-semibold text-neutral-800">{mockUser.name}</h2>
              <p className="text-neutral-500 mt-1">Student</p>
              <button className="mt-4 w-full py-2 bg-primary-500 text-white rounded-md hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-300 focus:ring-offset-2">
                Edit Profile
              </button>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <button
              className={`w-full flex items-center p-3 text-left ${
                activeTab === 'account'
                  ? 'bg-primary-50 text-primary-700 border-l-4 border-primary-500'
                  : 'hover:bg-neutral-50 text-neutral-700'
              }`}
              onClick={() => setActiveTab('account')}
            >
              <User className="w-5 h-5 mr-3" />
              <span>Account Information</span>
            </button>
            <button
              className={`w-full flex items-center p-3 text-left ${
                activeTab === 'preferences'
                  ? 'bg-primary-50 text-primary-700 border-l-4 border-primary-500'
                  : 'hover:bg-neutral-50 text-neutral-700'
              }`}
              onClick={() => setActiveTab('preferences')}
            >
              <Settings className="w-5 h-5 mr-3" />
              <span>Preferences</span>
            </button>
          </div>
        </div>
        
        <div className="lg:col-span-3">
          {activeTab === 'account' && (
            <AccountTab />
          )}
          
          {activeTab === 'preferences' && (
            <PreferencesTab />
          )}
        </div>
      </div>
    </div>
  );
};

const AccountTab: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-neutral-800 mb-4">Account Information</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Full Name
            </label>
            <input
              type="text"
              className="w-full p-2 border border-neutral-300 rounded-md focus:ring-2 focus:ring-primary-300 focus:border-primary-500 focus:outline-none"
              defaultValue={mockUser.name}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Email Address
            </label>
            <div className="flex">
              <input
                type="email"
                className="w-full p-2 border border-neutral-300 rounded-md focus:ring-2 focus:ring-primary-300 focus:border-primary-500 focus:outline-none"
                defaultValue="student@example.com"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Password
            </label>
            <div className="flex">
              <input
                type="password"
                className="w-full p-2 border border-neutral-300 rounded-md focus:ring-2 focus:ring-primary-300 focus:border-primary-500 focus:outline-none"
                defaultValue="••••••••"
              />
              <button className="ml-2 px-4 py-2 bg-neutral-100 text-neutral-700 rounded-md hover:bg-neutral-200 focus:outline-none focus:ring-2 focus:ring-primary-300">
                Change
              </button>
            </div>
          </div>
        </div>
        
        <div className="mt-6 flex justify-end">
          <button className="px-4 py-2 bg-primary-500 text-white rounded-md hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-300 focus:ring-offset-2">
            Save Changes
          </button>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-neutral-800 mb-4">Learning Statistics</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-primary-50 rounded-lg border border-primary-100">
            <div className="flex items-center">
              <BookOpen className="w-10 h-10 text-primary-500 mr-3" />
              <div>
                <h3 className="text-sm font-medium text-neutral-600">Problems Solved</h3>
                <p className="text-2xl font-semibold text-neutral-800">{mockUser.progress.completedProblems.length}</p>
              </div>
            </div>
          </div>
          
          <div className="p-4 bg-secondary-50 rounded-lg border border-secondary-100">
            <div className="flex items-center">
              <Award className="w-10 h-10 text-secondary-500 mr-3" />
              <div>
                <h3 className="text-sm font-medium text-neutral-600">Concepts Mastered</h3>
                <p className="text-2xl font-semibold text-neutral-800">{mockUser.progress.masteredConcepts.length}</p>
              </div>
            </div>
          </div>
          
          <div className="p-4 bg-accent-50 rounded-lg border border-accent-100">
            <div className="flex items-center">
              <User className="w-10 h-10 text-accent-500 mr-3" />
              <div>
                <h3 className="text-sm font-medium text-neutral-600">Current Level</h3>
                <p className="text-2xl font-semibold text-neutral-800">Intermediate</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const PreferencesTab: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-neutral-800 mb-4">Display Settings</h2>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-neutral-800">Dark Mode</h3>
              <p className="text-sm text-neutral-500">Switch between light and dark themes</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-neutral-800">Animation Effects</h3>
              <p className="text-sm text-neutral-500">Enable or disable animations</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-neutral-800">High Contrast Mode</h3>
              <p className="text-sm text-neutral-500">Increase contrast for better readability</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-neutral-800 mb-4">Notification Settings</h2>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-neutral-800">Email Notifications</h3>
              <p className="text-sm text-neutral-500">Receive problem recommendations via email</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-neutral-800">Learning Reminders</h3>
              <p className="text-sm text-neutral-500">Get reminders to practice regularly</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-neutral-800">Achievement Alerts</h3>
              <p className="text-sm text-neutral-500">Notifications when you earn achievements</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-neutral-800 mb-4">Learning Preferences</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Default Problem Difficulty
            </label>
            <select className="w-full p-2 border border-neutral-300 rounded-md focus:ring-2 focus:ring-primary-300 focus:border-primary-500 focus:outline-none">
              <option value="easy">Easy</option>
              <option value="medium" selected>Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Preferred Math Topics
            </label>
            <div className="space-y-2">
              <div className="flex items-center">
                <input
                  id="algebra"
                  type="checkbox"
                  className="w-4 h-4 text-primary-600 border-neutral-300 rounded focus:ring-primary-500"
                  defaultChecked
                />
                <label htmlFor="algebra" className="ml-2 text-sm text-neutral-700">
                  Algebra
                </label>
              </div>
              <div className="flex items-center">
                <input
                  id="geometry"
                  type="checkbox"
                  className="w-4 h-4 text-primary-600 border-neutral-300 rounded focus:ring-primary-500"
                  defaultChecked
                />
                <label htmlFor="geometry" className="ml-2 text-sm text-neutral-700">
                  Geometry
                </label>
              </div>
              <div className="flex items-center">
                <input
                  id="calculus"
                  type="checkbox"
                  className="w-4 h-4 text-primary-600 border-neutral-300 rounded focus:ring-primary-500"
                />
                <label htmlFor="calculus" className="ml-2 text-sm text-neutral-700">
                  Calculus
                </label>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-6 flex justify-end">
          <button className="px-4 py-2 bg-primary-500 text-white rounded-md hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-300 focus:ring-offset-2">
            Save Preferences
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;