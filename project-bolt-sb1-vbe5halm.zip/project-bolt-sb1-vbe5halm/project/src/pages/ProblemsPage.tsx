import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, SortAsc, BookOpen } from 'lucide-react';
import { mockProblems } from '../data/mockData';
import { Problem } from '../types';

const ProblemsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string | null>(null);
  const [filterDifficulty, setFilterDifficulty] = useState<string | null>(null);
  
  // Filter problems based on search and filters
  const filteredProblems = mockProblems.filter((problem) => {
    const matchesSearch = !searchTerm || 
      problem.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      problem.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = !filterType || problem.type === filterType;
    const matchesDifficulty = !filterDifficulty || problem.difficulty === filterDifficulty;
    
    return matchesSearch && matchesType && matchesDifficulty;
  });
  
  const typeOptions = ['algebra', 'geometry', 'calculus', 'other'];
  const difficultyOptions = ['easy', 'medium', 'hard'];
  
  return (
    <div className="max-w-5xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-neutral-800 mb-2">Problem Library</h1>
        <p className="text-neutral-600">
          Browse and search through our collection of interactive math problems
        </p>
      </motion.div>
      
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:space-x-4 space-y-3 md:space-y-0">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400" size={18} />
            <input
              type="text"
              placeholder="Search problems..."
              className="w-full pl-10 pr-4 py-2 border border-neutral-300 rounded-md focus:ring-2 focus:ring-primary-300 focus:border-primary-500 focus:outline-none"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="relative">
              <select
                className="appearance-none pl-8 pr-8 py-2 border border-neutral-300 rounded-md focus:ring-2 focus:ring-primary-300 focus:border-primary-500 focus:outline-none bg-white"
                value={filterType || ''}
                onChange={(e) => setFilterType(e.target.value || null)}
              >
                <option value="">All Types</option>
                {typeOptions.map((type) => (
                  <option key={type} value={type}>
                    {type.charAt(0).toUpperCase() + type.slice(1)}
                  </option>
                ))}
              </select>
              <Filter className="absolute left-2 top-1/2 transform -translate-y-1/2 text-neutral-400" size={16} />
            </div>
            
            <div className="relative">
              <select
                className="appearance-none pl-8 pr-8 py-2 border border-neutral-300 rounded-md focus:ring-2 focus:ring-primary-300 focus:border-primary-500 focus:outline-none bg-white"
                value={filterDifficulty || ''}
                onChange={(e) => setFilterDifficulty(e.target.value || null)}
              >
                <option value="">All Difficulties</option>
                {difficultyOptions.map((difficulty) => (
                  <option key={difficulty} value={difficulty}>
                    {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
                  </option>
                ))}
              </select>
              <SortAsc className="absolute left-2 top-1/2 transform -translate-y-1/2 text-neutral-400" size={16} />
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredProblems.length > 0 ? (
          filteredProblems.map((problem) => (
            <ProblemCard key={problem.id} problem={problem} />
          ))
        ) : (
          <div className="col-span-full text-center py-10">
            <BookOpen className="mx-auto h-12 w-12 text-neutral-400 mb-2" />
            <h3 className="text-lg font-medium text-neutral-700">No problems found</h3>
            <p className="text-neutral-500 mt-1">Try adjusting your search or filters</p>
          </div>
        )}
      </div>
    </div>
  );
};

interface ProblemCardProps {
  problem: Problem;
}

const ProblemCard: React.FC<ProblemCardProps> = ({ problem }) => {
  return (
    <motion.div
      whileHover={{ y: -5, boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)' }}
      transition={{ duration: 0.2 }}
      className="bg-white rounded-lg shadow-md overflow-hidden border border-neutral-200"
    >
      <div className="p-4">
        <div className="flex items-start justify-between">
          <h3 className="text-lg font-semibold text-neutral-800">{problem.title}</h3>
          <div 
            className={`ml-2 px-2 py-1 text-xs font-medium rounded-full ${
              problem.difficulty === 'easy'
                ? 'bg-success-100 text-success-700'
                : problem.difficulty === 'medium'
                ? 'bg-warning-100 text-warning-700'
                : 'bg-error-100 text-error-700'
            }`}
          >
            {problem.difficulty}
          </div>
        </div>
        
        <p className="text-neutral-600 text-sm mt-2 line-clamp-2">{problem.description}</p>
        
        <div className="flex items-center mt-4 space-x-2">
          <span 
            className={`px-2 py-1 text-xs font-medium rounded-full ${
              problem.type === 'algebra'
                ? 'bg-primary-100 text-primary-700'
                : problem.type === 'geometry'
                ? 'bg-secondary-100 text-secondary-700'
                : problem.type === 'calculus'
                ? 'bg-accent-100 text-accent-700'
                : 'bg-neutral-100 text-neutral-700'
            }`}
          >
            {problem.type}
          </span>
          
          <span 
            className={`px-2 py-1 text-xs font-medium rounded-full ${
              problem.visualizationType === 'geogebra'
                ? 'bg-primary-50 text-primary-600'
                : 'bg-secondary-50 text-secondary-600'
            }`}
          >
            {problem.visualizationType === 'geogebra' ? '2D' : '3D'} viz
          </span>
        </div>
      </div>
      
      <div className="border-t border-neutral-200 bg-neutral-50 px-4 py-3">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full py-1.5 bg-primary-500 text-white rounded-md hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-300 focus:ring-offset-2"
        >
          Solve Problem
        </motion.button>
      </div>
    </motion.div>
  );
};

export default ProblemsPage;