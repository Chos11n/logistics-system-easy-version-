import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAppStore } from '../store/appStore';
import TextInput from '../components/input/TextInput';
import ImageInput from '../components/input/ImageInput';
import InputSelector from '../components/input/InputSelector';
import GeoGebraWrapper from '../components/visualization/GeoGebraWrapper';
import ThreeJSWrapper from '../components/visualization/ThreeJSWrapper';
import VisualizationControls from '../components/visualization/VisualizationControls';
import FeedbackPanel from '../components/feedback/FeedbackPanel';
import { mockProblems } from '../data/mockData';

const HomePage: React.FC = () => {
  const { inputMode, setInputMode, visualizationMode } = useAppStore();
  const [activeProblem, setActiveProblem] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{
    status: 'correct' | 'incorrect' | 'partial' | 'pending';
    message?: string;
    suggestions?: string[];
  } | null>(null);

  const handleTextSubmit = (text: string) => {
    console.log('Submitted text:', text);
    // Simulate processing
    setFeedback({ status: 'pending' });
    
    // Simulate API call
    setTimeout(() => {
      setActiveProblem('quadratic');
      setFeedback({
        status: 'correct',
        message: 'Great job! Your solution is correct. The roots of the equation x² - 5x + 6 = 0 are x = 2 and x = 3.',
      });
    }, 1500);
  };

  const handleImageUpload = (file: File) => {
    console.log('Uploaded image:', file.name);
    // Simulate processing
    setFeedback({ status: 'pending' });
    
    // Simulate API call
    setTimeout(() => {
      setActiveProblem('triangle');
      setFeedback({
        status: 'partial',
        message: 'You\'re on the right track! Your approach is good, but there\'s a calculation error.',
        suggestions: [
          'Check your formula for the area of a triangle',
          'Make sure you\'re using the correct units',
          'Verify your intermediate calculations',
        ],
      });
    }, 2000);
  };
  
  const renderVisualization = () => {
    if (!activeProblem) return null;
    
    if (visualizationMode === '2d') {
      return (
        <GeoGebraWrapper
          id="ggb-element"
          commands={
            activeProblem === 'quadratic'
              ? ['f(x) = x^2 - 5x + 6', 'A = (2, 0)', 'B = (3, 0)']
              : ['A = (0, 0)', 'B = (4, 0)', 'C = (2, 3)', 'poly1 = Polygon(A, B, C)']
          }
          height="400px"
        />
      );
    } else {
      return (
        <ThreeJSWrapper
          height="400px"
          renderScene={(scene, camera) => {
            // Custom scene setup can be added here
          }}
        />
      );
    }
  };

  return (
    <div className="max-w-5xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-neutral-800 mb-2">Interactive Mathematics Learning</h1>
        <p className="text-neutral-600">
          Enter your math problem using text or upload an image to visualize and solve step by step.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <InputSelector activeMode={inputMode} onModeChange={setInputMode} />
          
          {inputMode === 'text' ? (
            <TextInput onSubmit={handleTextSubmit} />
          ) : (
            <ImageInput onImageUpload={handleImageUpload} />
          )}
          
          {feedback && (
            <FeedbackPanel
              status={feedback.status}
              message={feedback.message}
              suggestions={feedback.suggestions}
              onTryAgain={() => setFeedback(null)}
              onNextProblem={() => {
                setActiveProblem(null);
                setFeedback(null);
              }}
            />
          )}
          
          <div className="bg-white rounded-lg shadow-md p-4">
            <h2 className="text-lg font-semibold text-neutral-800 mb-3">Recent Problems</h2>
            <div className="space-y-3">
              {mockProblems.slice(0, 3).map((problem) => (
                <button
                  key={problem.id}
                  className="w-full text-left p-3 rounded-md hover:bg-primary-50 border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-primary-200"
                >
                  <div className="font-medium text-neutral-800">{problem.title}</div>
                  <div className="text-sm text-neutral-600 mt-1">{problem.description}</div>
                  <div className="flex space-x-2 mt-2">
                    <span className="text-xs px-2 py-0.5 bg-primary-100 text-primary-700 rounded-full">
                      {problem.type}
                    </span>
                    <span className="text-xs px-2 py-0.5 bg-neutral-100 text-neutral-700 rounded-full">
                      {problem.difficulty}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-4 mb-6">
            <h2 className="text-lg font-semibold text-neutral-800 mb-3">Visualization</h2>
            
            {activeProblem ? (
              <>
                <VisualizationControls
                  onReset={() => console.log('Reset visualization')}
                  onSave={() => console.log('Save visualization')}
                />
                {renderVisualization()}
              </>
            ) : (
              <div className="flex items-center justify-center h-60 bg-neutral-50 rounded-md border border-dashed border-neutral-300">
                <div className="text-center p-6">
                  <div className="text-neutral-400 mb-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-12 w-12 mx-auto"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                      />
                    </svg>
                  </div>
                  <p className="text-neutral-600">
                    Enter a problem to see the visualization here
                  </p>
                  <p className="text-sm text-neutral-500 mt-1">
                    Supports algebra, geometry, and calculus problems
                  </p>
                </div>
              </div>
            )}
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-4">
            <h2 className="text-lg font-semibold text-neutral-800 mb-3">Step-by-Step Solution</h2>
            
            {activeProblem ? (
              <div className="space-y-4">
                {activeProblem === 'quadratic' ? (
                  <>
                    <div className="p-3 border-l-4 border-primary-500 bg-primary-50">
                      <h3 className="font-medium text-primary-700">Step 1: Identify the equation</h3>
                      <p className="text-neutral-700 mt-1">
                        We have a quadratic equation in the form: ax² + bx + c = 0
                        <br />
                        x² - 5x + 6 = 0, where a = 1, b = -5, c = 6
                      </p>
                    </div>
                    <div className="p-3 border-l-4 border-primary-500 bg-primary-50">
                      <h3 className="font-medium text-primary-700">Step 2: Factor the equation</h3>
                      <p className="text-neutral-700 mt-1">
                        We need to find two numbers that multiply to give 6 and add to give -5
                        <br />
                        These numbers are -2 and -3
                        <br />
                        So, x² - 5x + 6 = (x - 2)(x - 3)
                      </p>
                    </div>
                    <div className="p-3 border-l-4 border-primary-500 bg-primary-50">
                      <h3 className="font-medium text-primary-700">Step 3: Find the roots</h3>
                      <p className="text-neutral-700 mt-1">
                        Set each factor equal to zero and solve:
                        <br />
                        x - 2 = 0 → x = 2
                        <br />
                        x - 3 = 0 → x = 3
                        <br />
                        The roots of the equation are x = 2 and x = 3
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="p-3 border-l-4 border-primary-500 bg-primary-50">
                      <h3 className="font-medium text-primary-700">Step 1: Identify the triangle</h3>
                      <p className="text-neutral-700 mt-1">
                        We have a triangle with sides 3, 4, and 5 units
                      </p>
                    </div>
                    <div className="p-3 border-l-4 border-primary-500 bg-primary-50">
                      <h3 className="font-medium text-primary-700">Step 2: Use Heron's formula</h3>
                      <p className="text-neutral-700 mt-1">
                        Area = √(s(s-a)(s-b)(s-c)), where s = (a+b+c)/2
                        <br />
                        s = (3+4+5)/2 = 6
                      </p>
                    </div>
                    <div className="p-3 border-l-4 border-primary-500 bg-primary-50">
                      <h3 className="font-medium text-primary-700">Step 3: Calculate the area</h3>
                      <p className="text-neutral-700 mt-1">
                        Area = √(6(6-3)(6-4)(6-5))
                        <br />
                        Area = √(6×3×2×1)
                        <br />
                        Area = √36 = 6 square units
                      </p>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="text-center py-8 text-neutral-500">
                Enter a problem to see the step-by-step solution
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;