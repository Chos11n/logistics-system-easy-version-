import React from 'react';
import { motion } from 'framer-motion';
import { Award, Book, CheckCircle, TrendingUp, Zap } from 'lucide-react';
import ProgressChart from '../components/progress/ProgressChart';
import { mockUser, mockConcepts, mockProblems } from '../data/mockData';

const ProgressPage: React.FC = () => {
  const { progress } = mockUser;
  
  // Calculate completion percentage
  const completionPercentage = (progress.completedProblems.length / mockProblems.length) * 100;
  
  // Calculate mastery percentage
  const masteryPercentage = (progress.masteredConcepts.length / mockConcepts.length) * 100;
  
  return (
    <div className="max-w-5xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-neutral-800 mb-2">Learning Progress</h1>
        <p className="text-neutral-600">
          Track your performance and growth in mathematical problem-solving
        </p>
      </motion.div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard
          title="Problems Completed"
          value={progress.completedProblems.length}
          total={mockProblems.length}
          icon={<CheckCircle className="w-8 h-8 text-primary-500" />}
          color="primary"
        />
        <StatCard
          title="Concepts Mastered"
          value={progress.masteredConcepts.length}
          total={mockConcepts.length}
          icon={<Zap className="w-8 h-8 text-secondary-500" />}
          color="secondary"
        />
        <StatCard
          title="Average Score"
          value={Math.round(
            progress.scoreHistory.reduce((acc, entry) => acc + entry.score, 0) /
              progress.scoreHistory.length
          )}
          suffix="%"
          icon={<TrendingUp className="w-8 h-8 text-accent-500" />}
          color="accent"
        />
        <StatCard
          title="Learning Streak"
          value={7}
          suffix=" days"
          icon={<Award className="w-8 h-8 text-warning-500" />}
          color="warning"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-4 mb-6">
            <h2 className="text-lg font-semibold text-neutral-800 mb-4">Performance Over Time</h2>
            <ProgressChart data={progress.scoreHistory} height={300} />
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-4">
            <h2 className="text-lg font-semibold text-neutral-800 mb-4">Recent Activity</h2>
            <div className="space-y-4">
              {progress.scoreHistory.slice(0, 5).map((entry, index) => {
                const concept = mockConcepts.find((c) => c.id === entry.conceptId);
                const relatedProblem = mockProblems.find((p) => p.concepts.includes(entry.conceptId));
                
                return (
                  <div key={index} className="flex items-start space-x-3 p-3 border-l-4 border-primary-300 bg-primary-50 rounded-r-md">
                    <div className="flex-shrink-0 mt-1">
                      <Book className="w-5 h-5 text-primary-500" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <h3 className="font-medium text-neutral-800">
                          {concept ? concept.name : 'Unknown Concept'}
                        </h3>
                        <span className="text-sm font-medium text-primary-700">{entry.score}%</span>
                      </div>
                      <p className="text-sm text-neutral-600 mt-1">
                        {relatedProblem ? relatedProblem.title : 'Practice session'}
                      </p>
                      <div className="text-xs text-neutral-500 mt-1">{entry.date}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-4 mb-6">
            <h2 className="text-lg font-semibold text-neutral-800 mb-4">Achievements</h2>
            <div className="space-y-3">
              <Achievement
                title="Problem Solver"
                description="Complete 5 problems"
                progress={progress.completedProblems.length}
                target={5}
                icon={<Award className="w-6 h-6" />}
                color="primary"
              />
              <Achievement
                title="Math Apprentice"
                description="Master 3 concepts"
                progress={progress.masteredConcepts.length}
                target={3}
                icon={<Book className="w-6 h-6" />}
                color="secondary"
              />
              <Achievement
                title="Perfect Score"
                description="Get 100% on a problem"
                progress={progress.scoreHistory.some((entry) => entry.score === 100) ? 1 : 0}
                target={1}
                icon={<CheckCircle className="w-6 h-6" />}
                color="success"
              />
              <Achievement
                title="Learning Streak"
                description="Practice for 7 consecutive days"
                progress={7}
                target={7}
                icon={<Zap className="w-6 h-6" />}
                color="warning"
              />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-4">
            <h2 className="text-lg font-semibold text-neutral-800 mb-4">Recommended Focus</h2>
            <div className="space-y-3">
              {mockConcepts.slice(0, 3).map((concept) => (
                <div
                  key={concept.id}
                  className="p-3 border border-neutral-200 rounded-md hover:border-primary-300 hover:bg-primary-50 transition-colors"
                >
                  <h3 className="font-medium text-neutral-800">{concept.name}</h3>
                  <p className="text-sm text-neutral-600 mt-1">{concept.description}</p>
                  <div className="mt-2">
                    <div className="relative pt-1">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-xs font-semibold inline-block text-primary-600">
                            Mastery: 35%
                          </span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-1 text-xs flex rounded bg-primary-100">
                        <div
                          style={{ width: '35%' }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-primary-500"
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface StatCardProps {
  title: string;
  value: number;
  total?: number;
  suffix?: string;
  icon: React.ReactNode;
  color: 'primary' | 'secondary' | 'accent' | 'warning' | 'success' | 'error';
}

const StatCard: React.FC<StatCardProps> = ({ title, value, total, suffix = '', icon, color }) => {
  const colorClasses = {
    primary: 'text-primary-500 bg-primary-50 border-primary-200',
    secondary: 'text-secondary-500 bg-secondary-50 border-secondary-200',
    accent: 'text-accent-500 bg-accent-50 border-accent-200',
    warning: 'text-warning-500 bg-warning-50 border-warning-200',
    success: 'text-success-500 bg-success-50 border-success-200',
    error: 'text-error-500 bg-error-50 border-error-200',
  };
  
  const percentage = total ? Math.round((value / total) * 100) : null;
  
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className={`p-4 rounded-lg border ${colorClasses[color]} shadow-sm`}
    >
      <div className="flex justify-between items-center">
        <h3 className="text-neutral-700 font-medium">{title}</h3>
        <div className="p-2 rounded-full bg-white shadow-sm">{icon}</div>
      </div>
      <div className="mt-3">
        <span className="text-2xl font-bold text-neutral-800">
          {value}
          {suffix}
        </span>
        {total && (
          <span className="text-sm text-neutral-500 ml-1">
            / {total} ({percentage}%)
          </span>
        )}
      </div>
      {total && (
        <div className="mt-2">
          <div className="w-full bg-neutral-200 rounded-full h-2">
            <div
              className={`h-2 rounded-full ${
                color === 'primary'
                  ? 'bg-primary-500'
                  : color === 'secondary'
                  ? 'bg-secondary-500'
                  : color === 'accent'
                  ? 'bg-accent-500'
                  : color === 'warning'
                  ? 'bg-warning-500'
                  : color === 'success'
                  ? 'bg-success-500'
                  : 'bg-error-500'
              }`}
              style={{ width: `${percentage}%` }}
            ></div>
          </div>
        </div>
      )}
    </motion.div>
  );
};

interface AchievementProps {
  title: string;
  description: string;
  progress: number;
  target: number;
  icon: React.ReactNode;
  color: 'primary' | 'secondary' | 'accent' | 'warning' | 'success' | 'error';
}

const Achievement: React.FC<AchievementProps> = ({
  title,
  description,
  progress,
  target,
  icon,
  color,
}) => {
  const colorClasses = {
    primary: 'text-primary-500 border-primary-200',
    secondary: 'text-secondary-500 border-secondary-200',
    accent: 'text-accent-500 border-accent-200',
    warning: 'text-warning-500 border-warning-200',
    success: 'text-success-500 border-success-200',
    error: 'text-error-500 border-error-200',
  };
  
  const isCompleted = progress >= target;
  const percentage = Math.min(Math.round((progress / target) * 100), 100);
  
  return (
    <div className={`p-3 border rounded-md ${isCompleted ? `${colorClasses[color]} bg-${color}-50` : 'border-neutral-200'}`}>
      <div className="flex items-center space-x-3">
        <div className={`p-2 rounded-full ${isCompleted ? `bg-${color}-100` : 'bg-neutral-100'}`}>
          {icon}
        </div>
        <div className="flex-1">
          <div className="flex justify-between">
            <h3 className="font-medium text-neutral-800">{title}</h3>
            <span className="text-sm font-medium text-neutral-700">
              {progress}/{target}
            </span>
          </div>
          <p className="text-xs text-neutral-600 mt-0.5">{description}</p>
          <div className="mt-2">
            <div className="w-full bg-neutral-200 rounded-full h-1.5">
              <div
                className={`h-1.5 rounded-full ${
                  color === 'primary'
                    ? 'bg-primary-500'
                    : color === 'secondary'
                    ? 'bg-secondary-500'
                    : color === 'accent'
                    ? 'bg-accent-500'
                    : color === 'warning'
                    ? 'bg-warning-500'
                    : color === 'success'
                    ? 'bg-success-500'
                    : 'bg-error-500'
                }`}
                style={{ width: `${percentage}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressPage;